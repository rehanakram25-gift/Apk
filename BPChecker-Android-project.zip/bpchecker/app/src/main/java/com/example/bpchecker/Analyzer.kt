package com.example.bpchecker

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class Candle(var k: Int, var x0: Int, var x1: Int, var top: Int, var bot: Int, var btop: Double, var bbot: Double) {
    var color: String = ""
    val w: Int get() = x1 - x0 + 1
}

/** Candle as price-like numbers (higher = up). */
class CV(val color: String, val o: Double, val c: Double, val h: Double, val l: Double) {
    val body: Double get() = abs(c - o)
}

class Level(var v: Double, var n: Int) {
    var role: String = "S"
    var d: Double = 0.0
    var sel: Boolean = false
}

class Match(val id: Int, val dir: String)

class Res(
    val ok: Boolean,
    val all: List<CV>,
    val closed: List<CV>,
    val matches: List<Match>,
    val trend: String,
    val snrNear: Boolean,
    val levels: List<Level>,
    val count: Int
)

object Analyzer {

    val NAMES: Map<Int, String> = mapOf(
        1 to "Buy - SNR reject then break",
        2 to "Sell - SNR reject then break",
        3 to "Buy - 4 reds (1+2+3 = 4)",
        4 to "Sell - 4 greens (1+2+3 = 4)",
        5 to "Buy - doji at SNR in down move",
        6 to "Sell - doji at SNR in up move",
        9 to "Buy - 2 greens engulfed by red",
        10 to "Sell - 2 reds engulfed by green",
        13 to "Buy - break SNR, red retest holds",
        14 to "Sell - break SNR, green retest holds",
        17 to "Buy - 3 shrinking reds + green engulf",
        18 to "Sell - 3 shrinking greens + red engulf",
        21 to "Buy - red pokes below green low, closes in body",
        22 to "Sell - green pokes above red high, closes in body",
        23 to "Buy - 3 greens + red = their sum",
        24 to "Sell - 3 reds + green = their sum",
        27 to "Buy - big green, 3 small reds, big green",
        28 to "Sell - big red, 3 small greens, big red",
        29 to "Buy - R-G-R, close = first open",
        30 to "Sell - G-R-G, close = first open"
    )

    /** 0 = nothing, 1 = green, 2 = red / orange-red. */
    fun classify(p: Int): Int {
        val r = (p shr 16) and 255
        val g = (p shr 8) and 255
        val b = p and 255
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        val d = mx - mn
        if (mx < 90 || d.toDouble() / mx < 0.45) return 0
        var h: Double
        if (mx == r) h = ((g - b).toDouble() / d) % 6.0
        else if (mx == g) h = (b - r).toDouble() / d + 2.0
        else h = (r - g).toDouble() / d + 4.0
        h *= 60.0
        if (h < 0) h += 360.0
        if (h >= 85.0 && h <= 170.0) return 1
        if (h <= 40.0 || h >= 340.0) return 2
        return 0
    }

    private fun ovl(top: Array<IntArray>, bot: Array<IntArray>, a: Int, x: Int, ref: Int): Int {
        return min(bot[a][x], bot[a][ref]) - max(top[a][x], top[a][ref]) + 1
    }

    private fun tmed(a: List<Double>): Double {
        val s = a.sorted()
        val m = s.size / 2
        return if (s.size % 2 == 1) s[m] else (s[m - 1] + s[m]) / 2.0
    }

    private fun mid(c: Candle): Double = (c.top + c.bot) / 2.0

    /** Reads candles from a cropped, masked pixel array (RGB ints). */
    fun detect(pix: IntArray, W: Int, H: Int): List<Candle> {
        val cl = ByteArray(W * H)
        for (p in 0 until W * H) cl[p] = classify(pix[p]).toByte()

        val cnt = Array(2) { IntArray(W) }
        val top = Array(2) { IntArray(W) { H } }
        val bot = Array(2) { IntArray(W) { -1 } }
        // per column: longest vertical run of candle colour
        for (x in 0 until W) {
            for (a in 0..1) {
                val want = (a + 1).toByte()
                var bs = -1
                var be = -1
                var cs = -1
                var ce = -1
                for (y in 0 until H) {
                    if (cl[y * W + x] == want) {
                        if (cs < 0 || y - ce > 3) cs = y
                        ce = y
                        if (bs < 0 || ce - cs > be - bs) {
                            bs = cs
                            be = ce
                        }
                    }
                }
                if (bs >= 0) {
                    cnt[a][x] = be - bs + 1
                    top[a][x] = bs
                    bot[a][x] = be
                }
            }
        }
        val colK = IntArray(W)
        for (x in 0 until W) {
            if (cnt[0][x] >= 1 && cnt[0][x] >= cnt[1][x]) colK[x] = 1
            else if (cnt[1][x] >= 1) colK[x] = 2
        }
        // group neighbouring columns of the same colour into candles
        val runs = ArrayList<IntArray>()
        var cur: IntArray? = null
        for (x in 0 until W) {
            val k = colK[x]
            if (k == 0) continue
            val c = cur
            if (c != null && c[0] == k && x - c[2] <= 2) {
                c[2] = x
            } else {
                if (c != null) runs.add(c)
                cur = intArrayOf(k, x, x)
            }
        }
        val lastRun = cur
        if (lastRun != null) runs.add(lastRun)

        var cands = ArrayList<Candle>()
        for (r0 in runs) {
            if (r0[2] - r0[1] + 1 < 3) continue
            val a = r0[0] - 1
            var ref = r0[1]
            for (x in r0[1]..r0[2]) {
                if (bot[a][x] - top[a][x] > bot[a][ref] - top[a][ref]) ref = x
            }
            var s0 = ref
            var e0 = ref
            // trim neighbouring objects (text, labels) lying in a different vertical band
            while (s0 > r0[1] && ovl(top, bot, a, s0 - 1, ref) >= 0.3 * (bot[a][s0 - 1] - top[a][s0 - 1] + 1)) s0--
            while (e0 < r0[2] && ovl(top, bot, a, e0 + 1, ref) >= 0.3 * (bot[a][e0 + 1] - top[a][e0 + 1] + 1)) e0++
            val w = e0 - s0 + 1
            if (w < 3) continue
            var t = H
            var b = -1
            for (x in s0..e0) {
                if (top[a][x] < t) t = top[a][x]
                if (bot[a][x] > b) b = bot[a][x]
            }
            val edge = max(1, w / 4)
            val xs = ArrayList<Int>()
            for (i in 0 until edge) {
                xs.add(s0 + i)
                xs.add(e0 - i)
            }
            var bt = 0.0
            var bb = 0.0
            for (x in xs) {
                bt += top[a][x]
                bb += bot[a][x]
            }
            bt /= xs.size
            bb /= xs.size
            cands.add(Candle(r0[0], s0, e0, t, b, bt, bb))
        }
        if (cands.isNotEmpty()) {
            val ws = cands.map { it.w }.sorted()
            val med = ws[ws.size / 2]
            cands = ArrayList(cands.filter { it.w <= med * 2.5 })
        }
        cands = ArrayList(clean(cands))
        if (cands.isEmpty()) return cands

        val tail = cands.takeLast(20).map { it.bbot - it.btop + 1 }.sorted()
        val medBody = tail[tail.size / 2]
        for (c in cands) {
            val bh = c.bbot - c.btop + 1
            c.color = if (bh <= max(2.5, 0.15 * medBody)) "doji" else if (c.k == 1) "green" else "red"
        }
        return cands
    }

    /** Keeps only the real candle row (drops tall bars, text blobs, strays). */
    private fun clean(c0: List<Candle>): List<Candle> {
        var c = ArrayList(c0)
        if (c.size < 6) return c
        val medH = tmed(c.map { (it.bot - it.top + 1).toDouble() })
        c = ArrayList(c.filter {
            val h = (it.bot - it.top + 1).toDouble()
            h <= max(3.2 * medH, 12.0) && h >= max(4.0, 0.1 * medH)
        })
        if (c.size < 6) return c
        val mh = tmed(c.map { (it.bot - it.top + 1).toDouble() })
        var guard = 0
        while (guard < 40 && c.size >= 6) {
            var worst = -1
            var wd = 0.0
            for (i in c.indices) {
                val nb = ArrayList<Double>()
                for (j in (i - 2)..(i + 2)) {
                    if (j != i && j >= 0 && j < c.size) nb.add(mid(c[j]))
                }
                val dev = abs(mid(c[i]) - tmed(nb))
                if (dev > wd) {
                    wd = dev
                    worst = i
                }
            }
            if (worst < 0 || wd <= max(2.5 * mh, 20.0)) break
            c.removeAt(worst)
            guard++
        }
        if (c.size < 4) return c
        val cx = c.map { (it.x0 + it.x1) / 2.0 }
        val gaps = ArrayList<Double>()
        for (i in 1 until cx.size) gaps.add(cx[i] - cx[i - 1])
        val sp = tmed(gaps)
        val chains = ArrayList<ArrayList<Candle>>()
        var cur = ArrayList<Candle>()
        cur.add(c[0])
        for (i in 1 until c.size) {
            if (gaps[i - 1] > 3.5 * sp) {
                chains.add(cur)
                cur = ArrayList()
            }
            cur.add(c[i])
        }
        chains.add(cur)
        var best = chains[0]
        for (ch in chains) {
            if (ch.size > best.size) best = ch
        }
        return best
    }

    /** base = screen height minus region top, so values stay comparable when the region changes. */
    fun toValues(c: Candle, base: Int): CV {
        val hi = (base - c.top).toDouble()
        val lo = (base - c.bot).toDouble()
        val bHi = base - c.btop
        val bLo = base - c.bbot
        val o: Double
        val cl: Double
        if (c.color == "green") {
            o = bLo
            cl = bHi
        } else if (c.color == "red") {
            o = bHi
            cl = bLo
        } else {
            o = (bHi + bLo) / 2.0
            cl = o
        }
        return CV(c.color, o, cl, hi, lo)
    }

    private fun rd(v: Double, c: CV): Double {
        return if (v >= c.l && v <= c.h) 0.0 else min(abs(v - c.h), abs(v - c.l))
    }

    /** Returns (levels to draw/list, levels near the latest candles sorted by closeness). */
    fun findLevels(cs: List<CV>, avg: Double): Pair<List<Level>, List<Level>> {
        val n = cs.size
        if (n < 7) return Pair(emptyList(), emptyList())
        val win = cs.takeLast(60)
        val m = win.size
        val piv = ArrayList<Double>()
        for (i in 2 until m - 2) {
            var isH = true
            var isL = true
            for (j in (i - 2)..(i + 2)) {
                if (win[j].h > win[i].h) isH = false
                if (win[j].l < win[i].l) isL = false
            }
            if (isH) piv.add(win[i].h)
            if (isL) piv.add(win[i].l)
        }
        piv.sort()
        val tol = 0.9 * avg
        val levels = ArrayList<Level>()
        var grp = ArrayList<Double>()
        fun flush() {
            if (grp.size >= 2) levels.add(Level(grp.sum() / grp.size, grp.size))
            grp = ArrayList()
        }
        for (v in piv) {
            if (grp.isNotEmpty() && v - grp[grp.size - 1] > tol) flush()
            grp.add(v)
        }
        flush()
        val ref = cs[n - 1].c
        val a = cs[n - 1]
        val b = cs[n - 2]
        for (lv in levels) {
            lv.role = if (lv.v > ref) "R" else "S"
            lv.d = min(rd(lv.v, a), rd(lv.v, b))
        }
        levels.sortWith(Comparator<Level> { p, q ->
            if (p.n != q.n) q.n - p.n else abs(p.v - ref).compareTo(abs(q.v - ref))
        })
        val keep = ArrayList(levels.take(6))
        val relevant = ArrayList(keep.filter { it.d <= 1.5 * avg }.sortedBy { it.d })
        if (relevant.isNotEmpty()) relevant[0].sel = true
        return Pair(keep, relevant)
    }

    private fun approx(a: Double, b: Double): Boolean = abs(a - b) <= 0.25 * max(max(a, b), 1.0)
    private fun isG(c: CV) = c.color == "green"
    private fun isR(c: CV) = c.color == "red"
    private fun isD(c: CV) = c.color == "doji"

    /** The 20 strategies that can be checked mechanically. [cs] ends with the latest candle. */
    fun matchPatterns(cs: List<CV>, trend: String, snr: Double?, avg: Double): List<Match> {
        val out = ArrayList<Match>()
        val n = cs.size
        if (n < 2) return out
        val L = cs[n - 1]
        val P = cs[n - 2]
        val tol = 0.1 * avg

        if (n >= 4) {
            val a0 = cs[n - 4]
            val a1 = cs[n - 3]
            val a2 = cs[n - 2]
            val a3 = cs[n - 1]
            val sum3 = a0.body + a1.body + a2.body
            if (isR(a0) && isR(a1) && isR(a2) && isR(a3) && approx(sum3, a3.body)) out.add(Match(3, "Up"))
            if (isG(a0) && isG(a1) && isG(a2) && isG(a3) && approx(sum3, a3.body)) out.add(Match(4, "Down"))
            val b0 = a0.body
            val b1 = a1.body
            val b2 = a2.body
            if (a0.color == a1.color && a1.color == a2.color && b1 < b0 * 0.85 && b2 < b1 * 0.85) {
                if (isR(a0) && isG(a3) && a3.c >= a2.o - tol && a3.o <= a2.c + tol) out.add(Match(17, "Up"))
                if (isG(a0) && isR(a3) && a3.c <= a2.o + tol && a3.o >= a2.c - tol) out.add(Match(18, "Down"))
            }
            if (isG(a0) && isG(a1) && isG(a2) && isR(a3) && approx(sum3, a3.body)) out.add(Match(23, "Up"))
            if (isR(a0) && isR(a1) && isR(a2) && isG(a3) && approx(sum3, a3.body)) out.add(Match(24, "Down"))
        }
        if (n >= 3) {
            val x = cs[n - 3]
            val y = cs[n - 2]
            val z = cs[n - 1]
            if (isG(x) && isG(y) && isR(z) && z.o >= y.c - tol && z.c <= x.o + tol) out.add(Match(9, "Up"))
            if (isR(x) && isR(y) && isG(z) && z.o <= y.c + tol && z.c >= x.o - tol) out.add(Match(10, "Down"))
            if (isR(x) && isG(y) && isR(z) && abs(z.c - x.o) <= 0.25 * avg) out.add(Match(29, "Up"))
            if (isG(x) && isR(y) && isG(z) && abs(z.c - x.o) <= 0.25 * avg) out.add(Match(30, "Down"))
        }
        if (n >= 5) {
            val big = cs[n - 5]
            val mids = cs.subList(n - 4, n - 1)
            val insideAll = mids.all { it.h <= big.h + tol && it.l >= big.l - tol && it.body <= 0.8 * avg }
            if (isG(big) && big.body >= 1.2 * avg && insideAll && mids.all { isR(it) } && isG(L) && L.body >= 1.2 * avg && L.c > big.h) out.add(Match(27, "Up"))
            if (isR(big) && big.body >= 1.2 * avg && insideAll && mids.all { isG(it) } && isR(L) && L.body >= 1.2 * avg && L.c < big.l) out.add(Match(28, "Down"))
        }
        if (isG(P) && isR(L) && L.l < P.l && L.c >= (P.o + P.c) / 2) out.add(Match(21, "Up"))
        if (isR(P) && isG(L) && L.h > P.h && L.c <= (P.o + P.c) / 2) out.add(Match(22, "Down"))

        if (snr != null) {
            val s: Double = snr
            if (isD(L) && trend == "Down" && L.l <= s && L.h >= s && L.c > s) out.add(Match(5, "Up"))
            if (isD(L) && trend == "Up" && L.l <= s && L.h >= s && L.c < s) out.add(Match(6, "Down"))
            if (trend == "Up" && isR(P) && P.h >= s && P.c < s && isG(L) && L.c > s) out.add(Match(1, "Up"))
            if (trend == "Down" && isG(P) && P.l <= s && P.c > s && isR(L) && L.c < s) out.add(Match(2, "Down"))
            if (trend == "Up" && isG(P) && P.o < s && P.c > s && isR(L) && L.l <= s && L.c > s) out.add(Match(13, "Up"))
            if (trend == "Down" && isR(P) && P.o > s && P.c < s && isG(L) && L.h >= s && L.c < s) out.add(Match(14, "Down"))
        }
        return out
    }
}
