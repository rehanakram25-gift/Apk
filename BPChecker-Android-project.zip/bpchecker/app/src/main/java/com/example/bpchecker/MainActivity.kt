package com.example.bpchecker

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val reqCapture = 1001
    private val reqNotif = 1002
    private var askedNotif = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(24), dp(18), dp(24))
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val title = TextView(this)
        title.text = "BP Checker"
        title.textSize = 26f
        col.addView(title)

        val info = TextView(this)
        info.textSize = 15f
        info.setPadding(0, dp(10), 0, dp(14))
        info.text = "Floating chart analyzer for a DEMO account (learning only).\n\n" +
            "1. Allow 'display over other apps'.\n" +
            "2. Press Start and accept the screen-capture question.\n" +
            "3. Open the Quotex app. A small panel floats on top. Drag it by its title to a place that does not cover the candles.\n\n" +
            "The panel finds the candles, support/resistance and the candle timing by itself, shows UP or DOWN a few seconds before each new candle, and scores every signal on the next candle.\n\n" +
            "Keep the phone in one orientation while it runs. Zoom the Quotex chart in so candles are wide."
        col.addView(info)

        val b1 = Button(this)
        b1.text = "1. Allow display over other apps"
        b1.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
        }
        col.addView(b1)

        val b2 = Button(this)
        b2.text = "2. Start floating analyzer"
        b2.setOnClickListener { startFlow() }
        col.addView(b2)

        val b3 = Button(this)
        b3.text = "Stop analyzer"
        b3.setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Stopped", Toast.LENGTH_SHORT).show()
        }
        col.addView(b3)

        setContentView(scroll)
    }

    private fun startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Press button 1 first and allow 'display over other apps'.", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !askedNotif &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif)
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqNotif) startFlow()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, OverlayService::class.java)
                i.putExtra("code", resultCode)
                i.putExtra("data", data)
                startForegroundService(i)
                Toast.makeText(this, "Started. Now open the Quotex app.", Toast.LENGTH_LONG).show()
                finish()
            } else {
                Toast.makeText(this, "Screen capture was not allowed.", Toast.LENGTH_LONG).show()
            }
        }
    }
}
