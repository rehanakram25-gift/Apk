package com.example.bpchecker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioManager
import android.media.ImageReader
import android.media.ToneGenerator
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {

    private var wm: WindowManager? = null
    private var root: LinearLayout? = null
    private var tvCd: TextView? = null
    private var tvSig: TextView? = null
    private var tvSub: TextView? = null
    private var tvLive: TextView? = null
    private var tvStats: TextView? = null
    private var btnTf: Button? = null
    private var btnLead: Button? = null
    private var body: LinearLayout? = null

    private val ui = Handler(Looper.getMainLooper())
    private var scanThread: HandlerThread? = null
    private var scanHandler: Handler? = null
    private var engine: Engine? = null

    private var projection: MediaProjection? = null
    private var vdisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null

    @Volatile private var lastFrame: Frame? = null
    @Volatile private var mask: IntArray? = null
    private var statsOn = false
    private var running = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY
        val code = intent.getIntExtra("code", 0)
        val data = intent.getParcelableExtra<Intent>("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        try {
            startCapture(code, data)
        } catch (e: Throwable) {
            Toast.makeText(this, "Could not start screen capture: " + e.message, Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        buildOverlay()
        startEngine()
        running = true
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val chId = "bpc_channel"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(chId, "BP Checker", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, chId)
            .setContentTitle("BP Checker is running")
            .setContentText("Reading the shared screen (demo practice)")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data)
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                ui.post { stopSelf() }
            }
        }, ui)
        val dm = DisplayMetrics()
        val w = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        w.defaultDisplay.getRealMetrics(dm)
        val rd = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        reader = rd
        vdisplay = mp.createVirtualDisplay(
            "bpc", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, null
        )
    }

    /** Latest screen picture as RGB ints (re-uses the previous one if the screen has not changed). */
    private fun grab(): Frame? {
        val rd = reader ?: return lastFrame
        val img = rd.acquireLatestImage() ?: return lastFrame
        try {
            val w = img.width
            val h = img.height
            val plane = img.planes[0]
            val buf = plane.buffer
            val ps = plane.pixelStride
            val rs = plane.rowStride
            val bytes = ByteArray(buf.remaining())
            buf.get(bytes)
            val pix = IntArray(w * h)
            for (y in 0 until h) {
                var o = y * rs
                val row = y * w
                for (x in 0 until w) {
                    if (o + 2 >= bytes.size) break
                    pix[row + x] = ((bytes[o].toInt() and 255) shl 16) or ((bytes[o + 1].toInt() and 255) shl 8) or (bytes[o + 2].toInt() and 255)
                    o += ps
                }
            }
            val f = Frame(pix, w, h)
            lastFrame = f
            return f
        } finally {
            img.close()
        }
    }

    private fun smallBtn(text: String): Button {
        val b = Button(this)
        b.text = text
        b.textSize = 11f
        b.isAllCaps = false
        b.minWidth = 0
        b.minHeight = 0
        b.setPadding(dp(6), dp(4), dp(6), dp(4))
        return b
    }

    private fun weighted(b: Button): Button {
        b.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        return b
    }

    private fun buildOverlay() {
        val w = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm = w
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setBackgroundColor(Color.parseColor("#EE0F172A"))
        r.setPadding(dp(8), dp(6), dp(8), dp(8))
        root = r

        // header (drag handle + minimise + close)
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "BP Checker (drag here)"
        title.setTextColor(Color.WHITE)
        title.textSize = 13f
        title.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val bMin = smallBtn("-")
        val bClose = smallBtn("X")
        head.addView(title)
        head.addView(bMin)
        head.addView(bClose)
        r.addView(head)

        val bd = LinearLayout(this)
        bd.orientation = LinearLayout.VERTICAL
        body = bd

        val cd = TextView(this)
        cd.setTextColor(Color.parseColor("#94a3b8"))
        cd.textSize = 12f
        cd.gravity = Gravity.CENTER
        cd.setPadding(0, dp(4), 0, 0)
        tvCd = cd
        bd.addView(cd)

        val sg = TextView(this)
        sg.textSize = 26f
        sg.gravity = Gravity.CENTER
        sg.setTypeface(sg.typeface, android.graphics.Typeface.BOLD)
        sg.setPadding(0, dp(8), 0, dp(8))
        tvSig = sg
        bd.addView(sg)

        val sb = TextView(this)
        sb.setTextColor(Color.parseColor("#cbd5e1"))
        sb.textSize = 11f
        tvSub = sb
        bd.addView(sb)

        val lv = TextView(this)
        lv.setTextColor(Color.parseColor("#64748b"))
        lv.textSize = 10f
        lv.setPadding(0, dp(4), 0, dp(4))
        tvLive = lv
        bd.addView(lv)

        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        val bAnalyze = weighted(smallBtn("Analyze"))
        val bSync = weighted(smallBtn("Sync"))
        val bTf = weighted(smallBtn("TF 60s"))
        btnTf = bTf
        row1.addView(bAnalyze)
        row1.addView(bSync)
        row1.addView(bTf)
        bd.addView(row1)

        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        val bLead = weighted(smallBtn("Lead 3s"))
        btnLead = bLead
        val bStats = weighted(smallBtn("Scores"))
        val bReset = weighted(smallBtn("Reset"))
        row2.addView(bLead)
        row2.addView(bStats)
        row2.addView(bReset)
        bd.addView(row2)

        val st = TextView(this)
        st.setTextColor(Color.parseColor("#e2e8f0"))
        st.textSize = 11f
        st.visibility = View.GONE
        tvStats = st
        bd.addView(st)

        r.addView(bd)

        val p = WindowManager.LayoutParams(
            dp(280),
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = dp(8)
        p.y = dp(80)

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        head.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_DOWN) {
                startX = p.x
                startY = p.y
                touchX = ev.rawX
                touchY = ev.rawY
            } else if (ev.action == MotionEvent.ACTION_MOVE) {
                p.x = startX + (ev.rawX - touchX).toInt()
                p.y = startY + (ev.rawY - touchY).toInt()
                w.updateViewLayout(r, p)
            }
            true
        }

        bMin.setOnClickListener {
            if (bd.visibility == View.VISIBLE) {
                bd.visibility = View.GONE
                bMin.text = "+"
            } else {
                bd.visibility = View.VISIBLE
                bMin.text = "-"
            }
            w.updateViewLayout(r, p)
        }
        bClose.setOnClickListener { stopSelf() }
        bAnalyze.setOnClickListener { scanHandler?.post { engine?.analyzeNow() } }
        bSync.setOnClickListener { scanHandler?.post { engine?.syncNow() } }
        bTf.setOnClickListener { scanHandler?.post { engine?.cycleTf() } }
        bLead.setOnClickListener { scanHandler?.post { engine?.cycleLead() } }
        bStats.setOnClickListener {
            statsOn = !statsOn
            w.updateViewLayout(r, p)
        }
        bReset.setOnClickListener { scanHandler?.post { engine?.resetStats() } }

        w.addView(r, p)
    }

    private val poll = object : Runnable {
        override fun run() {
            val e = engine
            if (e != null) {
                tvCd?.text = e.countdown
                tvSig?.text = e.sigText
                val kind = e.sigKind
                tvSig?.setBackgroundColor(Color.parseColor(if (kind == 1) "#14532d" else if (kind == 2) "#7f1d1d" else "#1e293b"))
                tvSig?.setTextColor(Color.parseColor(if (kind == 1) "#bbf7d0" else if (kind == 2) "#fecaca" else "#94a3b8"))
                tvSub?.text = e.sub
                tvLive?.text = e.live + "\n" + e.syncNote
                btnTf?.text = "TF " + e.tfSec + "s"
                btnLead?.text = "Lead " + e.leadSec + "s"
                val st = tvStats
                if (st != null) {
                    if (statsOn) {
                        st.visibility = View.VISIBLE
                        st.text = e.statsText
                    } else {
                        st.visibility = View.GONE
                    }
                }
            }
            val r = root
            if (r != null) {
                val loc = IntArray(2)
                r.getLocationOnScreen(loc)
                mask = intArrayOf(loc[0], loc[1], loc[0] + r.width, loc[1] + r.height)
            }
            ui.postDelayed(this, 250)
        }
    }

    private fun alertUser() {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(350, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Throwable) {
        }
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 250)
        } catch (e: Throwable) {
        }
    }

    private fun startEngine() {
        val t = HandlerThread("bpc-scan")
        t.start()
        scanThread = t
        val h = Handler(t.looper)
        scanHandler = h
        val e = Engine(
            { grab() },
            { mask },
            getSharedPreferences("bpc", Context.MODE_PRIVATE),
            { ui.post { alertUser() } }
        )
        engine = e
        h.post(object : Runnable {
            override fun run() {
                try {
                    e.step()
                } catch (ex: Throwable) {
                    e.live = "Error: " + ex.message
                }
                h.postDelayed(this, 300)
            }
        })
        ui.post(poll)
    }

    override fun onDestroy() {
        ui.removeCallbacks(poll)
        scanHandler?.removeCallbacksAndMessages(null)
        scanThread?.quitSafely()
        try {
            val r = root
            if (r != null) wm?.removeView(r)
        } catch (e: Throwable) {
        }
        try { vdisplay?.release() } catch (e: Throwable) { }
        try { reader?.close() } catch (e: Throwable) { }
        try { projection?.stop() } catch (e: Throwable) { }
        running = false
        super.onDestroy()
    }
}
