package com.example.bpchecker

import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class Frame(val pix: IntArray, val w: Int, val h: Int)

class Pend(val id: Int, val dir: String, val openAt: Long, val last: CV, val time: String)

/**
 * Runs on a background thread: step() is called about 3 times a second.
 * - finds the candle area by itself
 * - reads candles, finds support/resistance, matches the strategies
 * - learns the candle timeframe and exact candle-open moment from the chart
 * - shows UP / DOWN a few seconds before the next candle opens
 * - scores each signal on the following candle
 */
class Engine(
    private val getFrame: () -> Frame?,
    private val getMask: () -> IntArray?,
    private val prefs: SharedPreferences,
    private val onSignal: () -> Unit
) {
    @Volatile var countdown: String = "Next candle opens in --"
    @Volatile var sigText: String = "WAITING"
    @Volatile var sigKind: Int = 0          // 0 none, 1 up, 2 down
    @Volatile var sub: String = "Open the Quotex chart. The signal appears a few seconds before each new candle."
    @Volatile var live: String = ""
    @Volatile var syncNote: String = "Waiting to sync: needs to see a candle open on the chart."
    @Volatile var statsText: String = ""
    @Volatile var tfSec: Int = 60
    @Volatile var leadSec: Int = 3

    private val STD = intArrayOf(5, 10, 15, 30, 60, 120, 180, 300, 600, 900)
    private val LEADS = intArrayOf(2, 3, 4, 5)

    private var region: IntArray? = null
    private var lastFitTs = 0L
    private var offsetMs = 0L
    private var autoSync = true
    private var sigCycle = -1L
    private var prevAll: List<CV>? = null
    private var prevScanTs = 0L
    private val openEvents = ArrayList<Long>()
    private val skews = ArrayList<Long>()
    private val ivStd = ArrayList<Int>()
    private var tfNote = ""
    private val pendings = ArrayList<Pend>()
    private val stats = HashMap<Int, IntArray>()   // id -> [wins, losses, ties]
    private var lastRes: Res? = null
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    init {
        loadStats()
        buildStatsText()
    }

    // ---------------------------------------------------------------- main loop
    fun step() {
        val now = System.currentTimeMillis()
        val tf = tfSec * 1000L
        val t = now - offsetMs
        val cycle = Math.floorDiv(t, tf)
        val remMs = tf - Math.floorMod(t, tf)
        countdown = "Next candle opens in " + String.format(Locale.US, "%.1f", remMs / 1000.0) + " s"

        val fr = getFrame()
        if (fr == null) {
            live = "Waiting for screen frames..."
            return
        }
        val all = detectAll(fr)
        track(all, now)
        val res = analyze(all, true)
        lastRes = res
        val ms = res.matches.joinToString(" ") { it.id.toString() + (if (it.dir == "Up") "^" else "v") }
        live = if (!res.ok) {
            "Live: only " + res.count + " candle(s) found. Zoom the chart in and keep the panel off the candles."
        } else {
            "Live: " + res.count + " candles, trend " + res.trend.lowercase(Locale.US) + ", " + res.levels.size + " S/R, matching: " + (if (ms.isEmpty()) "none" else ms)
        }

        // 1) signal moment: a few seconds before the next candle opens
        if (remMs <= leadSec * 1000L && cycle != sigCycle) {
            sigCycle = cycle
            makeSignal(res, now + remMs, now)
        }
        // 2) scoring moment: 1 s after the predicted candle has closed
        val due = pendings.filter { now >= it.openAt + tf + 1000 }
        if (due.isNotEmpty()) {
            pendings.removeAll(due)
            scoreDue(due, all)
        }
    }

    // ---------------------------------------------------------------- reading the chart
    private fun detectRegion(fr: Frame, rg: IntArray): List<Candle> {
        val w = rg[2]
        val h = rg[3]
        val pix = IntArray(w * h)
        for (y in 0 until h) {
            System.arraycopy(fr.pix, (rg[1] + y) * fr.w + rg[0], pix, y * w, w)
        }
        val mask = getMask()
        if (mask != null) {
            val mx0 = max(mask[0], rg[0])
            val my0 = max(mask[1], rg[1])
            val mx1 = min(mask[2], rg[0] + w)
            val my1 = min(mask[3], rg[1] + h)
            if (mx0 < mx1 && my0 < my1) {
                for (ay in my0 until my1) {
                    for (ax in mx0 until mx1) pix[(ay - rg[1]) * w + (ax - rg[0])] = 0
                }
            }
        }
        return Analyzer.detect(pix, w, h)
    }

    private fun detectAll(fr: Frame): List<CV> {
        var rg: IntArray = region ?: intArrayOf(0, 0, fr.w, fr.h)
        var cands = detectRegion(fr, rg)
        val nr = fitRegion(cands, rg, fr)
        if (nr != null) {
            region = nr
            rg = nr
            cands = detectRegion(fr, rg)
        }
        val base = fr.h - rg[1]
        return cands.map { Analyzer.toValues(it, base) }
    }

    /** Finds the candle area automatically and re-fits it when candles reach its edge. */
    private fun fitRegion(l: List<Candle>, base: IntArray, fr: Frame): IntArray? {
        if (l.size < 8) return null
        val now = System.currentTimeMillis()
        if (region != null && now - lastFitTs < 4000) return null
        val w = base[2]
        val h = base[3]
        var minTop = Int.MAX_VALUE
        var maxBot = Int.MIN_VALUE
        for (c in l) {
            if (c.top < minTop) minTop = c.top
            if (c.bot > maxBot) maxBot = c.bot
        }
        val gaps = ArrayList<Double>()
        for (i in 1 until l.size) gaps.add((l[i].x0 + l[i].x1) / 2.0 - (l[i - 1].x0 + l[i - 1].x1) / 2.0)
        gaps.sort()
        val sp = max(6.0, gaps[gaps.size / 2])
        val span = max(30, maxBot - minTop)
        val need = region == null || minTop < 0.03 * h || maxBot > 0.97 * h || l[l.size - 1].x1 > w - 1.2 * sp || span < 0.3 * h
        if (!need) return null
        val padY = max(24.0, 0.25 * span)
        val x0 = max(0.0, base[0] + l[0].x0 - 1.5 * sp)
        val y0 = max(0.0, base[1] + minTop - padY)
        val x1 = min(fr.w.toDouble(), base[0] + l[l.size - 1].x1 + 3.0 * sp)
        val y1 = min(fr.h.toDouble(), base[1] + maxBot + padY)
        if (x1 - x0 < 80 || y1 - y0 < 60) return null
        lastFitTs = now
        return intArrayOf(x0.toInt(), y0.toInt(), (x1 - x0).toInt(), (y1 - y0).toInt())
    }

    private fun analyze(all: List<CV>, includeForming: Boolean): Res {
        val closed = if (includeForming) all else all.dropLast(1)
        if (closed.size < 3) {
            return Res(false, all, closed, emptyList(), "Flat", false, emptyList(), all.size)
        }
        val bodies = closed.takeLast(20).filter { it.color != "doji" }.map { it.body }.sorted()
        val avg = if (bodies.isEmpty()) 5.0 else bodies[bodies.size / 2]
        var trend = "Flat"
        val w8 = closed.takeLast(8)
        if (w8.size >= 6) {
            val f = (w8[0].c + w8[1].c + w8[2].c) / 3.0
            val l = (w8[w8.size - 1].c + w8[w8.size - 2].c + w8[w8.size - 3].c) / 3.0
            trend = if (l - f > avg) "Up" else if (f - l > avg) "Down" else "Flat"
        }
        val lv = Analyzer.findLevels(closed, avg)
        val rel = lv.second
        val snrList: List<Double?> = if (rel.isEmpty()) listOf<Double?>(null) else rel.map { it.v }
        val seen = HashSet<Int>()
        val matches = ArrayList<Match>()
        for (sv in snrList) {
            for (m in Analyzer.matchPatterns(closed, trend, sv, avg)) {
                if (seen.add(m.id)) matches.add(m)
            }
        }
        return Res(true, all, closed, matches, trend, rel.isNotEmpty(), lv.first, all.size)
    }

    // ---------------------------------------------------------------- reading candle openings from the chart
    private fun track(all: List<CV>, now: Long) {
        if (all.size < 6) return
        val cur = all.takeLast(5)
        val pa = prevAll
        if (pa != null && now - prevScanTs < 3000) {
            var st = 0
            var sh = 0
            for (j in 0..3) {
                if (abs(cur[4 - j].o - pa[4 - j].o) <= 3) st++
                if (abs(cur[3 - j].o - pa[4 - j].o) <= 3) sh++
            }
            if (sh >= 3 && sh > st) onNewCandle(now - (now - prevScanTs) / 2)
        }
        prevAll = cur
        prevScanTs = now
    }

    private fun onNewCandle(t: Long) {
        val last: Long? = if (openEvents.isEmpty()) null else openEvents[openEvents.size - 1]
        if (last != null && t - last < 2000) return
        openEvents.add(t)
        if (openEvents.size > 10) openEvents.removeAt(0)
        if (!autoSync) return
        if (last != null) {
            val iv = (t - last) / 1000.0
            var std = 0
            for (s in STD) {
                if (abs(iv - s) <= max(1.5, 0.04 * s)) {
                    std = s
                    break
                }
            }
            ivStd.add(std)
            if (ivStd.size > 3) ivStd.removeAt(0)
            val n = ivStd.size
            if (n >= 2 && ivStd[n - 1] != 0 && ivStd[n - 1] == ivStd[n - 2] && ivStd[n - 1] != tfSec) {
                tfSec = ivStd[n - 1]
                skews.clear()
                sigCycle = -1L
                pendings.clear()
                tfNote = "Timeframe read from chart: " + tfSec + " s. "
            }
        }
        val tf = tfSec * 1000L
        val x = Math.floorMod(t, tf)
        val sk = if (x > tf / 2) x - tf else x
        skews.add(sk)
        if (skews.size > 5) skews.removeAt(0)
        val s = skews.sorted()
        offsetMs = s[s.size / 2]
        syncNote = tfNote + "Auto-synced to the chart (" + skews.size + " candle open(s) seen, offset " + String.format(Locale.US, "%.1f", offsetMs / 1000.0) + " s)."
    }

    // ---------------------------------------------------------------- signals and scoring
    private fun makeSignal(res: Res, openAt: Long, now: Long) {
        if (!res.ok) {
            sigKind = 0
            sigText = "CHART NOT READABLE"
            sub = "Keep the Quotex chart visible and zoomed in so candles are wide."
            return
        }
        val last = res.closed[res.closed.size - 1]
        val ups = res.matches.filter { it.dir == "Up" }
        val downs = res.matches.filter { it.dir == "Down" }
        val openStr = fmt.format(Date(openAt))
        val ids = res.matches.joinToString(", ") { it.id.toString() }
        if (res.matches.isEmpty()) {
            sigKind = 0
            sigText = "NO SIGNAL"
            sub = "No pattern matched before the candle opening at " + openStr + "."
        } else if (ups.isNotEmpty() && downs.isNotEmpty()) {
            sigKind = 0
            sigText = "CONFLICT - SKIP"
            sub = "Patterns " + ids + " disagree. Candle at " + openStr + "."
        } else {
            val up = ups.isNotEmpty()
            sigKind = if (up) 1 else 2
            sigText = if (up) "UP" else "DOWN"
            sub = "For the candle opening at " + openStr + ". Pattern " + ids + ". Read from the still-forming candle, so a last-second move can change it."
            onSignal()
        }
        val ts = fmt.format(Date(now))
        for (m in res.matches) pendings.add(Pend(m.id, m.dir, openAt, last, ts))
    }

    private fun scoreDue(due: List<Pend>, all: List<CV>) {
        val closed = all.dropLast(1)           // the right-most candle is the new, still forming one
        if (closed.size < 2) return
        val p = closed[closed.size - 1]
        val s = closed[closed.size - 2]
        for (d in due) {
            if (abs(s.o - d.last.o) > 4) continue      // chart alignment lost, do not score
            val st = stats.getOrPut(d.id) { IntArray(3) }
            if (p.color == "doji") st[2]++
            else if ((d.dir == "Up" && p.color == "green") || (d.dir == "Down" && p.color == "red")) st[0]++
            else st[1]++
        }
        saveStats()
        buildStatsText()
    }

    // ---------------------------------------------------------------- buttons
    fun analyzeNow() {
        val r = lastRes
        if (r == null || !r.ok) {
            sub = "Not enough candles yet. Zoom the chart in and keep the panel off the candles."
            return
        }
        val rs = r.levels.joinToString(", ") { it.role + " x" + it.n }
        val ms = if (r.matches.isEmpty()) "none" else r.matches.joinToString("; ") { (Analyzer.NAMES[it.id] ?: "") + " [" + it.id + "] -> " + it.dir }
        sub = r.count.toString() + " candles, trend " + r.trend.lowercase(Locale.US) + ". Levels: " + (if (rs.isEmpty()) "none" else rs) + ". Matches: " + ms
    }

    fun syncNow() {
        val tf = tfSec * 1000L
        val x = Math.floorMod(System.currentTimeMillis(), tf)
        offsetMs = if (x > tf / 2) x - tf else x
        autoSync = false
        sigCycle = -1L
        syncNote = "Manual sync applied (auto-sync is off)."
    }

    fun cycleTf() {
        var i = 0
        for (k in STD.indices) if (STD[k] == tfSec) i = k
        tfSec = STD[(i + 1) % STD.size]
        skews.clear()
        ivStd.clear()
        sigCycle = -1L
        pendings.clear()
    }

    fun cycleLead() {
        var i = 0
        for (k in LEADS.indices) if (LEADS[k] == leadSec) i = k
        leadSec = LEADS[(i + 1) % LEADS.size]
    }

    fun resetStats() {
        stats.clear()
        saveStats()
        buildStatsText()
    }

    // ---------------------------------------------------------------- score storage
    private fun loadStats() {
        val s = prefs.getString("stats", "") ?: ""
        if (s.isEmpty()) return
        for (part in s.split(";")) {
            val f = part.split(":")
            if (f.size == 4) {
                val id = f[0].toIntOrNull() ?: continue
                stats[id] = intArrayOf(f[1].toIntOrNull() ?: 0, f[2].toIntOrNull() ?: 0, f[3].toIntOrNull() ?: 0)
            }
        }
    }

    private fun saveStats() {
        val sb = StringBuilder()
        for ((id, v) in stats) {
            if (sb.isNotEmpty()) sb.append(";")
            sb.append(id).append(":").append(v[0]).append(":").append(v[1]).append(":").append(v[2])
        }
        prefs.edit().putString("stats", sb.toString()).apply()
    }

    private fun buildStatsText() {
        val ids = stats.keys.sorted()
        if (ids.isEmpty()) {
            statsText = "No scored signals yet. A signal is a win if the next candle closes in its direction (doji = tie). Break-even at 85% payout is about 54%."
            return
        }
        var tw = 0
        var tl = 0
        for (id in ids) {
            val v = stats[id]
            if (v != null) {
                tw += v[0]
                tl += v[1]
            }
        }
        val sb = StringBuilder()
        sb.append("Break-even at 85% payout: 54%. Overall ").append(tw).append("W / ").append(tl).append("L")
        if (tw + tl > 0) sb.append(" (").append(100 * tw / (tw + tl)).append("%)")
        sb.append("\n")
        for (id in ids) {
            val v = stats[id] ?: continue
            val n = v[0] + v[1]
            sb.append("#").append(id).append("  ").append(v[0]).append("W ").append(v[1]).append("L")
            if (n > 0) sb.append("  ").append(100 * v[0] / n).append("%")
            sb.append(if (n >= 30) "" else "  (need 30+)").append("\n")
        }
        statsText = sb.toString()
    }
}
